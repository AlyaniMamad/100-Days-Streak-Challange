#include<stdio.h>
#include<stdlib.h>

struct process {
    int pid, arrival_time, burst_time, waiting_time, turnaround_time, completion_time;
};

typedef struct process Process;

void sort(Process p[], int n) {
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (p[i].arrival_time > p[j].arrival_time) {
                Process temp = p[i];
                p[i] = p[j];
                p[j] = temp;
            }
        }
    }
}

int main() {
    int n, i, j;
    float avg_waiting_time = 0, avg_turnaround_time = 0;

    printf("Enter the number of processes: ");
    scanf("%d", &n);

    Process p[n];

    printf("\nEnter process details (arrival time and burst time):\n");

    for (i = 0; i < n; i++) {
        printf("Process %d: ", i+1);
        scanf("%d %d", &p[i].arrival_time, &p[i].burst_time);
        p[i].pid = i+1;
    }

    sort(p, n);

    p[0].completion_time = p[0].burst_time;
    p[0].turnaround_time = p[0].completion_time - p[0].arrival_time;
    p[0].waiting_time = p[0].turnaround_time - p[0].burst_time;

    for (i = 1; i < n; i++) {
        int min_burst_time = p[i].burst_time;
        int min_burst_time_index = i;

        for (j = i+1; j < n && p[j].arrival_time <= p[i-1].completion_time; j++) {
            if (p[j].burst_time < min_burst_time) {
                min_burst_time = p[j].burst_time;
                min_burst_time_index = j;
            }
        }

        if (min_burst_time_index != i) {
            Process temp = p[i];
            p[i] = p[min_burst_time_index];
            p[min_burst_time_index] = temp;
        }

        p[i].completion_time = p[i-1].completion_time + p[i].burst_time;
        p[i].turnaround_time = p[i].completion_time - p[i].arrival_time;
        p[i].waiting_time = p[i].turnaround_time - p[i].burst_time;
    }
    printf("\n\n=======================================================================================");
    printf("\n\t\t\t\tShortest Job First(SJF) ");
    printf("\n=======================================================================================\n");
    printf("Gantt Chart :\n");
    for (i = 0; i < n; i++) {
        printf("|  P%d  ", p[i].pid);
    }

    printf("|\n");

    printf("0");
    for (i = 0; i < n; i++) {
        printf("     %.2d", p[i].completion_time);
    }

    printf("\n\nProcess Details:\n");
    printf("PID\tArrival Time\tBurst Time\tWaiting Time\tTurnaround Time\tCompletion Time\n");

    for (i = 0; i < n; i++) {
        printf("%d\t%d\t\t%d\t\t%d\t\t%d\t\t\t%d\n", p[i].pid, p[i].arrival_time, p[i].burst_time, p[i].waiting_time, p[i].turnaround_time, p[i].completion_time);

        avg_waiting_time += p[i].waiting_time;
        avg_turnaround_time += p[i].turnaround_time;
    }

    avg_waiting_time /= n;
    avg_turnaround_time /= n;

    printf("\nAverage Waiting Time: %.2f", avg_waiting_time);
    printf("\nAverage Turnaround Time: %.2f\n", avg_turnaround_time);

    return 0;
}
